// background.js — Velox service worker

chrome.runtime.onInstalled.addListener(() => {
  console.log('[Velox] Extension installed/updated');
  chrome.storage.local.set({
    botActive: false,
    botStatus: 'IDLE',
    botStep: 0,
    logs: [],
    stats: { attempts: 0, reloads: 0, foundTicket: null }
  });
});

// Listen for tab updates — if bot is active and lands on ticket site, relay config
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (
    changeInfo.status === 'complete' &&
    tab.url &&
    tab.url.startsWith('https://ticket.allobankfest.com/')
  ) {
    chrome.storage.local.get(['botActive', 'config'], (data) => {
      if (data.botActive && data.config) {
        // Content script will auto-start via storage check
        // But send a message too in case it's ready
        setTimeout(() => {
          chrome.tabs.sendMessage(tabId, {
            action: 'START_BOT',
            config: data.config
          }).catch(() => {}); // content script handles it via storage too
        }, 1000);
      }
    });
  }
});
