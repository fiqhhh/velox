// content.js — Velox content script

(function () {
  'use strict';

  let cfg = null;
  let retryCount = 0;
  let isRunning = false;
  let checkIntervalId = null;

  // ─── UTILITY ───────────────────────────────────────────────
  function now() {
    return new Date().toLocaleTimeString('id-ID', { hour12: false });
  }

  function log(msg, type = 'info') {
    console.log(`[Velox] ${msg}`);
    chrome.storage.local.get('logs', (data) => {
      const logs = data.logs || [];
      logs.push({ msg, type, time: now() });
      if (logs.length > 200) logs.splice(0, logs.length - 200);
      chrome.storage.local.set({ logs });
    });

    // On-page UI log (if debug mode)
    if (cfg && cfg.debugMode) {
      updatePageLog(msg);
    }
  }

  function setStep(n) {
    chrome.storage.local.set({ botStep: n });
  }

  function incStat(key, val) {
    chrome.storage.local.get('stats', (data) => {
      const stats = data.stats || { attempts: 0, reloads: 0, foundTicket: null };
      if (typeof val === 'number') {
        stats[key] = (stats[key] || 0) + val;
      } else {
        stats[key] = val;
      }
      chrome.storage.local.set({ stats });
    });
  }

  function setBotStatus(status) {
    chrome.storage.local.set({ botStatus: status });
  }

  // ─── ON-PAGE LOG UI ─────────────────────────────────────────
  function updatePageLog(msg) {
    let box = document.getElementById('velox-log');
    if (!box) {
      box = document.createElement('div');
      box.id = 'velox-log';
      box.style.cssText = `
        position:fixed;bottom:12px;right:12px;
        background:rgba(10,10,15,0.92);
        color:#a855f7;padding:12px 14px;border-radius:10px;
        font-size:12px;max-width:300px;z-index:99999;
        line-height:1.7;font-family:'Space Mono',monospace;
        border:1px solid rgba(124,58,237,0.4);
        box-shadow:0 8px 32px rgba(0,0,0,0.6);
        backdrop-filter:blur(8px);
      `;
      document.body.appendChild(box);
    }
    const line = document.createElement('div');
    line.style.cssText = 'border-bottom:1px solid rgba(255,255,255,0.05);padding-bottom:3px;margin-bottom:3px;color:#e2e8f0;';
    line.innerHTML = `<span style="color:#64748b">${now()}</span> ${msg}`;
    box.appendChild(line);
    // Keep last 12 lines
    while (box.children.length > 12) box.removeChild(box.firstChild);
  }

  // ─── SOUND ALERT ────────────────────────────────────────────
  function playBeep() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 880;
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.4);
    } catch (e) {}
  }

  // ─── SORT TICKETS ────────────────────────────────────────────
  function sortTickets(rows, strategy) {
    const tierOrder = ['vip', 'gold', 'platinum', 'silver', 'red', 'pink', 'blue', 'green', 'yellow', 'purple', 'orange', 'white', 'grey'];
    const rowsArr = Array.from(rows);

    if (strategy === 'random') {
      return rowsArr.sort(() => Math.random() - 0.5);
    }
    if (strategy === 'highest-tier') {
      return rowsArr.sort((a, b) => {
        const na = getTicketName(a);
        const nb = getTicketName(b);
        return tierOrder.indexOf(na) - tierOrder.indexOf(nb);
      });
    }
    if (strategy === 'lowest-tier') {
      return rowsArr.sort((a, b) => {
        const na = getTicketName(a);
        const nb = getTicketName(b);
        return tierOrder.indexOf(nb) - tierOrder.indexOf(na);
      });
    }
    return rowsArr; // first-available
  }

  function getTicketName(row) {
    const label = row.querySelector('.stage-tag');
    return label ? label.textContent.trim().toLowerCase() : '';
  }

  // ─── MAIN BOT LOGIC ─────────────────────────────────────────
  function startBot(config) {
    if (isRunning) return;
    cfg = config;
    isRunning = true;
    setBotStatus('RUNNING');
    log('🚀 Velox dimulai!', 'success');
    setStep(1);
    incStat('attempts', 1);

    if (checkIntervalId) clearInterval(checkIntervalId);

    checkIntervalId = setInterval(() => {
      tryFillForm();
    }, cfg.checkInterval || 500);
  }

  function tryFillForm() {
    const inputs = document.querySelectorAll('.el-input__inner');
    const cityCheckbox = document.querySelector(`input[value="${cfg.cityValue}"]`);

    // Determine ticket container selector
    const daySelector = cfg.ticketDay === 'any' ? '.ticket-row' : `.${cfg.ticketDay} .ticket-row`;
    const ticketRows = document.querySelectorAll(daySelector);

    if (inputs.length >= 5 && cityCheckbox && ticketRows.length > 0) {
      clearInterval(checkIntervalId);
      checkIntervalId = null;
      log('✅ Form ditemukan, mengisi data...', 'success');
      setStep(1);

      // Fill inputs
      const values = [cfg.name, cfg.email, cfg.email, cfg.phone, cfg.phone];
      values.forEach((v, i) => {
        if (inputs[i]) {
          inputs[i].value = v;
          inputs[i].dispatchEvent(new Event('input', { bubbles: true }));
        }
      });
      log('📝 Data diri diisi', 'info');

      // Check city
      if (!cityCheckbox.checked) {
        cityCheckbox.click();
        log(`☑️ Kota "${cfg.cityValue}" dicentang`, 'info');
      }

      setStep(2);

      // Select ticket
      const allowedTypes = cfg.ticketTypes || [];
      const sorted = sortTickets(ticketRows, cfg.pickStrategy || 'first-available');

      const targetTicket = sorted.find(row => {
        const name = getTicketName(row);
        const plusBtn = row.querySelectorAll('button.el-button--mini')[1];
        const isSoldOut = row.querySelector('.soldout');
        if (!plusBtn || isSoldOut) return false;
        return allowedTypes.includes(name) && !plusBtn.disabled;
      });

      if (targetTicket) {
        const name = getTicketName(targetTicket).toUpperCase();
        const plusBtn = targetTicket.querySelectorAll('button.el-button--mini')[1];

        // Click plus button for requested count
        const count = cfg.ticketCount || 1;
        for (let i = 0; i < count; i++) {
          setTimeout(() => {
            plusBtn.click();
          }, i * 120);
        }

        if (cfg.soundAlert) playBeep();
        log(`🎫 Tiket dipilih: ${name} × ${count}`, 'success');
        incStat('foundTicket', name);
        setStep(3);

        // Proceed to confirm
        setTimeout(() => {
          doFirstConfirm();
        }, cfg.confirmDelay || 1000);

      } else {
        log('❌ Tidak ada tiket tersedia sesuai pilihan', 'error');
        if (cfg.autoReload) {
          const maxRetry = cfg.maxRetry || 0;
          if (maxRetry === 0 || retryCount < maxRetry) {
            retryCount++;
            incStat('reloads', 1);
            log(`🔄 Reload ke-${retryCount}${maxRetry > 0 ? '/' + maxRetry : ''}...`, 'warn');
            setBotStatus('WAITING');
            setTimeout(() => {
              isRunning = false;
              location.reload();
            }, cfg.reloadDelay || 1000);
          } else {
            log(`🛑 Max retry (${maxRetry}) tercapai. Bot berhenti.`, 'error');
            isRunning = false;
            setBotStatus('IDLE');
            chrome.storage.local.set({ botActive: false });
          }
        } else {
          isRunning = false;
          setBotStatus('IDLE');
        }
      }
    } else {
      log('🔍 Menunggu form...', 'info');
    }
  }

  function doFirstConfirm() {
    const btn = document.querySelector('.captcha-validate .el-button:not(.is-disabled)');
    if (btn) {
      btn.click();
      log('👉 Konfirmasi pertama diklik', 'info');
      setStep(4);
      waitForTnC();
    } else {
      log('⚠️ Tombol konfirmasi pertama tidak ditemukan', 'warn');
      // Retry after 500ms
      setTimeout(doFirstConfirm, 500);
    }
  }

  function waitForTnC() {
    if (!cfg.autoConfirm) {
      log('⏸️ autoConfirm off — selesaikan TnC & CAPTCHA manual', 'warn');
      return;
    }

    let tncAttempts = 0;
    const tncInterval = setInterval(() => {
      tncAttempts++;
      if (tncAttempts > 40) {
        clearInterval(tncInterval);
        log('⚠️ Timeout menunggu TnC', 'warn');
        return;
      }

      const cbSyarat = document.querySelector('input[value="syarat"]');
      const cbPrivacy = document.querySelector('input[value="privacy"]');

      if (cbSyarat && cbPrivacy) {
        clearInterval(tncInterval);

        if (!cbSyarat.checked) {
          cbSyarat.click();
          cbSyarat.dispatchEvent(new Event('change', { bubbles: true }));
          log('☑️ Syarat dicentang', 'info');
        }

        setTimeout(() => {
          if (!cbPrivacy.checked) {
            cbPrivacy.click();
            cbPrivacy.dispatchEvent(new Event('change', { bubbles: true }));
            log('☑️ Privacy dicentang', 'info');
          }

          setTimeout(() => {
            const finalBtn = document.querySelector('.confirm-info-dialog button.el-button--default:not(.is-disabled)');
            if (finalBtn) {
              finalBtn.click();
              log('🚀 Konfirmasi akhir diklik! Selesaikan CAPTCHA manual.', 'success');
              setStep(5);
              setBotStatus('IDLE');
              isRunning = false;
              chrome.storage.local.set({ botActive: false });
            } else {
              log('⚠️ Tombol konfirmasi akhir belum aktif, coba lagi...', 'warn');
              setTimeout(() => {
                const retryBtn = document.querySelector('.confirm-info-dialog button.el-button--default:not(.is-disabled)');
                if (retryBtn) {
                  retryBtn.click();
                  log('🚀 Konfirmasi akhir diklik (retry)!', 'success');
                  setStep(5);
                }
                isRunning = false;
                setBotStatus('IDLE');
                chrome.storage.local.set({ botActive: false });
              }, 500);
            }
          }, cfg.tncDelay || 300);

        }, cfg.tncDelay || 300);
      } else {
        if (tncAttempts % 4 === 0) {
          log('⏳ Menunggu dialog TnC...', 'warn');
        }
      }
    }, 500);
  }

  // ─── MESSAGE LISTENER ────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'START_BOT') {
      startBot(msg.config);
      sendResponse({ ok: true });
    }
    if (msg.action === 'STOP_BOT') {
      isRunning = false;
      if (checkIntervalId) clearInterval(checkIntervalId);
      setBotStatus('IDLE');
      chrome.storage.local.set({ botActive: false });
      log('⏹ Bot dihentikan manual', 'warn');
      sendResponse({ ok: true });
    }
    return true;
  });

  // ─── AUTO-START on page load if bot was active ───────────────
  chrome.storage.local.get(['botActive', 'config'], (data) => {
    if (data.botActive && data.config) {
      // Small delay to let page render
      setTimeout(() => {
        log('♻️ Bot dilanjutkan setelah reload', 'info');
        startBot(data.config);
      }, 800);
    }
  });

})();
