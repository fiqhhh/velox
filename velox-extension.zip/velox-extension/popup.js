// popup.js

const DEFAULT_CONFIG = {
  name: '',
  email: '',
  phone: '',
  cityValue: 'bandung',
  ticketDay: 'haritwo',
  ticketTypes: ['pink', 'red', 'blue', 'green', 'yellow', 'purple', 'orange', 'white'],
  ticketCount: 1,
  pickStrategy: 'first-available',
  checkInterval: 500,
  confirmDelay: 1000,
  tncDelay: 300,
  autoReload: true,
  reloadDelay: 1000,
  soundAlert: true,
  autoConfirm: true,
  debugMode: false,
  maxRetry: 0,
};

// --- TAB SWITCHING ---
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById('tab-' + tab.dataset.tab).classList.add('active');

    if (tab.dataset.tab === 'log') {
      loadLog();
    }
  });
});

// --- RANGE DISPLAYS ---
function bindRange(id, displayId, suffix = 'ms') {
  const input = document.getElementById(id);
  const display = document.getElementById(displayId);
  if (!input || !display) return;
  input.addEventListener('input', () => {
    display.textContent = input.value + suffix;
  });
}

bindRange('checkInterval', 'checkIntervalVal', 'ms');
bindRange('confirmDelay', 'confirmDelayVal', 'ms');
bindRange('tncDelay', 'tncDelayVal', 'ms');
bindRange('reloadDelay', 'reloadDelayVal', 'ms');

const ticketCountInput = document.getElementById('ticketCount');
const ticketCountVal = document.getElementById('ticketCountVal');
ticketCountInput.addEventListener('input', () => {
  const v = ticketCountInput.value;
  ticketCountVal.textContent = v + ' tiket';
});

// --- LOAD CONFIG ---
function loadConfig() {
  chrome.storage.local.get('config', (data) => {
    const cfg = Object.assign({}, DEFAULT_CONFIG, data.config || {});
    applyConfig(cfg);
  });
}

function applyConfig(cfg) {
  setValue('name', cfg.name);
  setValue('email', cfg.email);
  setValue('phone', cfg.phone);
  setValue('cityValue', cfg.cityValue);
  setValue('ticketDay', cfg.ticketDay);
  setValue('ticketCount', cfg.ticketCount);
  setValue('pickStrategy', cfg.pickStrategy);
  setValue('checkInterval', cfg.checkInterval);
  setValue('confirmDelay', cfg.confirmDelay);
  setValue('tncDelay', cfg.tncDelay);
  setValue('autoReload', cfg.autoReload);
  setValue('reloadDelay', cfg.reloadDelay);
  setValue('soundAlert', cfg.soundAlert);
  setValue('autoConfirm', cfg.autoConfirm);
  setValue('debugMode', cfg.debugMode);
  setValue('maxRetry', cfg.maxRetry);

  // Ticket types
  document.querySelectorAll('input[name="ticketType"]').forEach(cb => {
    cb.checked = (cfg.ticketTypes || []).includes(cb.value);
  });

  // Update range displays
  document.getElementById('ticketCountVal').textContent = cfg.ticketCount + ' tiket';
  document.getElementById('checkIntervalVal').textContent = cfg.checkInterval + 'ms';
  document.getElementById('confirmDelayVal').textContent = cfg.confirmDelay + 'ms';
  document.getElementById('tncDelayVal').textContent = cfg.tncDelay + 'ms';
  document.getElementById('reloadDelayVal').textContent = cfg.reloadDelay + 'ms';
}

function setValue(id, val) {
  const el = document.getElementById(id);
  if (!el) return;
  if (el.type === 'checkbox') {
    el.checked = !!val;
  } else {
    el.value = val;
  }
}

// --- SAVE CONFIG ---
function getConfig() {
  const ticketTypes = Array.from(document.querySelectorAll('input[name="ticketType"]:checked')).map(cb => cb.value);
  return {
    name: val('name'),
    email: val('email'),
    phone: val('phone'),
    cityValue: val('cityValue'),
    ticketDay: val('ticketDay'),
    ticketTypes,
    ticketCount: parseInt(val('ticketCount')) || 1,
    pickStrategy: val('pickStrategy'),
    checkInterval: parseInt(val('checkInterval')) || 500,
    confirmDelay: parseInt(val('confirmDelay')) || 1000,
    tncDelay: parseInt(val('tncDelay')) || 300,
    autoReload: checked('autoReload'),
    reloadDelay: parseInt(val('reloadDelay')) || 1000,
    soundAlert: checked('soundAlert'),
    autoConfirm: checked('autoConfirm'),
    debugMode: checked('debugMode'),
    maxRetry: parseInt(val('maxRetry')) || 0,
  };
}

function val(id) {
  const el = document.getElementById(id);
  return el ? el.value : '';
}
function checked(id) {
  const el = document.getElementById(id);
  return el ? el.checked : false;
}

document.getElementById('saveBtn').addEventListener('click', () => {
  const cfg = getConfig();
  chrome.storage.local.set({ config: cfg }, () => {
    showToast('✅ Config tersimpan!');
  });
});

// --- INJECT / RUN BOT ---
document.getElementById('injectBtn').addEventListener('click', () => {
  const cfg = getConfig();
  chrome.storage.local.set({ config: cfg, botActive: true, stats: { attempts: 0, reloads: 0, foundTicket: null } }, () => {
    // Find active [target site] tab or open one
    chrome.tabs.query({ url: 'https://ticket.[target site].com/*' }, (tabs) => {
      if (tabs.length > 0) {
        const tab = tabs[0];
        chrome.tabs.update(tab.id, { active: true });
        chrome.tabs.sendMessage(tab.id, { action: 'START_BOT', config: cfg }, (response) => {
          if (chrome.runtime.lastError) {
            // Content script might not be ready, reload tab
            chrome.tabs.reload(tab.id);
          }
        });
        showToast('🚀 Bot diaktifkan!');
      } else {
        chrome.tabs.create({ url: 'https://ticket.[target site].com/' }, () => {
          showToast('🌐 Membuka halaman tiket...');
        });
      }
    });
  });
});

// --- TOAST ---
function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2200);
}

// --- STATUS BADGE ---
function updateStatus() {
  chrome.storage.local.get(['botActive', 'botStatus'], (data) => {
    const badge = document.getElementById('statusBadge');
    const text = document.getElementById('statusText');
    badge.className = 'status-badge';

    if (data.botActive) {
      if (data.botStatus === 'RUNNING') {
        badge.classList.add('active');
        text.textContent = 'RUNNING';
      } else if (data.botStatus === 'WAITING') {
        badge.classList.add('waiting');
        text.textContent = 'WAITING';
      } else {
        badge.classList.add('active');
        text.textContent = 'ACTIVE';
      }
    } else {
      text.textContent = 'IDLE';
    }
  });
}

// --- LOG ---
function loadLog() {
  chrome.storage.local.get(['logs', 'stats', 'botStep'], (data) => {
    const container = document.getElementById('logContainer');
    const logs = data.logs || [];
    const stats = data.stats || { attempts: 0, reloads: 0, foundTicket: null };

    document.getElementById('statAttempts').textContent = stats.attempts;
    document.getElementById('statReloads').textContent = stats.reloads;
    document.getElementById('statFound').textContent = stats.foundTicket || '—';

    // Update steps
    const step = data.botStep || 0;
    for (let i = 1; i <= 5; i++) {
      const el = document.getElementById('step' + i);
      el.className = 'step';
      if (i < step) el.classList.add('done');
      else if (i === step) el.classList.add('active');
    }

    if (logs.length === 0) {
      container.innerHTML = '<div class="log-empty">Log kosong. Aktifkan bot di halaman tiket.</div>';
      return;
    }

    container.innerHTML = logs.slice(-80).map(log => {
      const cls = log.type || 'info';
      const time = log.time || '';
      return `<div class="log-entry ${cls}"><span class="log-time">${time}</span>${escapeHTML(log.msg)}</div>`;
    }).join('');
    container.scrollTop = container.scrollHeight;
  });
}

function escapeHTML(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

document.getElementById('clearLog').addEventListener('click', () => {
  chrome.storage.local.set({ logs: [], stats: { attempts: 0, reloads: 0, foundTicket: null }, botStep: 0 });
  loadLog();
});

document.getElementById('refreshLog').addEventListener('click', loadLog);

// --- INIT ---
loadConfig();
updateStatus();

// Poll status every 2 seconds while popup is open
setInterval(updateStatus, 2000);

// Listen for storage changes (log updates from content script)
chrome.storage.onChanged.addListener((changes) => {
  if (changes.logs || changes.stats || changes.botStep) {
    const activeTab = document.querySelector('.tab.active');
    if (activeTab && activeTab.dataset.tab === 'log') {
      loadLog();
    }
  }
  if (changes.botStatus || changes.botActive) {
    updateStatus();
  }
});
