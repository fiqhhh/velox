# 🎫 Velox — Velox

> Chrome Extension untuk auto-isi form tiket **Allobankfest** dengan konfigurasi lengkap.

![version](https://img.shields.io/badge/version-2.0-7c3aed?style=flat-square)
![chrome](https://img.shields.io/badge/Chrome-88%2B-4285F4?style=flat-square&logo=googlechrome&logoColor=white)
![manifest](https://img.shields.io/badge/Manifest-V3-22c55e?style=flat-square)

---

## ✨ Fitur

- 📝 **Auto-fill form** — nama, email, HP terisi otomatis
- 🎫 **Filter tiket pintar** — pilih tipe, hari, dan strategi pemilihan
- 🔢 **Multi-tiket** — beli 1–8 tiket sekaligus
- 🔄 **Auto reload** — reload otomatis jika tiket habis
- ⚡ **Kecepatan custom** — interval check 100ms–2000ms
- 📋 **Live log** — pantau proses real-time dari popup
- 🔔 **Notif suara** — beep saat tiket ditemukan

---

## 📦 Cara Install

### 1. Download & Extract
Buka `INSTALL.html` di browser untuk panduan visual, atau ikuti langkah berikut:

Download ZIP lalu extract ke folder mana saja, atau:
```bash
git clone https://github.com/USERNAME/velox.git
```

### 2. Buka Chrome Extensions
```
chrome://extensions
```
Aktifkan **Developer Mode** (toggle kanan atas).

### 3. Load Extension
Klik **"Load unpacked"** → pilih folder `velox-extension`.

Icon 🎫 muncul di toolbar = berhasil!

---

## 🚀 Cara Pakai

1. Klik icon 🎫 → isi **Config** (nama, email, HP, kota)
2. Atur **Tiket** (tipe, jumlah, strategi)
3. Atur **Lanjutan** (kecepatan, reload, dll)
4. Klik **💾 Simpan** → **▶ Jalankan Bot**
5. Pantau di tab **📋 Log**
6. Selesaikan **CAPTCHA manual** saat muncul

---

## ⚠️ Disclaimer

Extension untuk keperluan personal. Gunakan sesuai T&C event. Pembuat tidak bertanggung jawab atas penyalahgunaan.

---
*Selamat berburu tiket! 🎫*
